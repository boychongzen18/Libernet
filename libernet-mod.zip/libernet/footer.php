<footer class="text-center">
    <font color="white">© 2021 <a href="https://github.com/lutfailham96/libernet">Libernet</a> v1.5.3. All rights reserved. | MOD BY </font><a href="https://t.me/hanifwidiwidodo">Hanif Widi Widodo</a>
</footer>
